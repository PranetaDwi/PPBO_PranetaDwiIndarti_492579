public class pieChart {
    subject chart;

    public pieChart(subject chart){
        this.chart = chart;
    }
}
